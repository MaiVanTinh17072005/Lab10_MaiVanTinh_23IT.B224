@extends('layout') 
@section('product') 

<h3>Trang san pham</h3> 
<p>Nội dung trang san pham!!!</p> 
</div> 
@endsection
