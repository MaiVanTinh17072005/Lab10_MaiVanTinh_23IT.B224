@extends('layout') 
@section('contact') 

<h3>Trang lien he</h3> 
<p>Nội dung trang lien he!!!</p> 
</div> 
@endsection
