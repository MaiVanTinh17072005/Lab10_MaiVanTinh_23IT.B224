<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Gửi mail google</title>
</head>
<body>
	<h1>Mail được gửi từ shop : {{$name}}</h1>
	
</body>
</html>