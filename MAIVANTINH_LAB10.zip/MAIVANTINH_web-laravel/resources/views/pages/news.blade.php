@extends('layout') 
@section('news') 
<h3>Tin trong ngày</h3> 
<p>Nội dung siêu ngắn cho tin tức mới đây!!!</p> 
</div> 
@endsection
